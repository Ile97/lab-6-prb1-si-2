
package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner s = new Scanner(new File("examen.txt"));
        List<Integer> grades = new ArrayList<Integer>();

        while (s.hasNext()) {
            s.next();
            grades.add(Integer.valueOf(s.next()));
        }
        int i = 0;
        float sum = 0;
        for (int grade : grades) {
            i++;
            sum += grade;

        }
        float avg = sum / i;
        BufferedWriter writer = new BufferedWriter(new FileWriter("media.txt"));
        writer.write(String.valueOf(avg));

        writer.close();

    }
}
