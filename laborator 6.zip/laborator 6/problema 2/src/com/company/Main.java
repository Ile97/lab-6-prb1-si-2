package com.company;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class Main {
    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new FileReader("an.txt"));

        ArrayList<students> studentRecords = new ArrayList<students>();


        String currentLine = reader.readLine();

        while (currentLine != null) {
            String[] studentDetail = currentLine.split(" ");

            String name = studentDetail[0];
            String surname = studentDetail[1];

            int marks = Integer.valueOf(studentDetail[2]);


            studentRecords.add(new students(name, surname, marks));

            currentLine = reader.readLine();
        }


        Collections.sort(studentRecords, new nameCompare());


        BufferedWriter writer = new BufferedWriter(new FileWriter("an_sort.txt"));


        for (Student student : studentRecords) {
            writer.write(student.name);
            writer.write(" " + student.surname);
            writer.write(" " + student.marks);

            writer.newLine();
        }

        reader.close();

        writer.close();
    }
}
