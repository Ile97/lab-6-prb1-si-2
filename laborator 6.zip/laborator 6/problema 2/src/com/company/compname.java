package com.company;

import java.util.Comparator;

public class compname {
    package com.company;




    class nameCompare implements Comparator <students> {
        @Override
        public int compare(students s1, students s2) {
            return s1.name.compareTo(s2.name);
        }
    }
}
