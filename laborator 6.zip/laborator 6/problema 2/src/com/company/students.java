package com.company;

public class students {
    package com.company;

    public class students {
        String name;
        String surname;
        int marks;

        public students(String name, String surname, int marks) {
            this.name = name;
            this.surname = surname;
            this.marks = marks;
        }
    }
}
